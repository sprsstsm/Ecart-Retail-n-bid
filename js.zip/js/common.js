function validReg(){
        var username = $('#username').val();
        var useremail = $('#useremail').val();
        var password = $('#password').val();
        var repassword = $('#repassword').val();
        var country = $('#country').val();
        var atpos=useremail.indexOf('@');
        var dotpos=useremail.lastIndexOf('.');
        
        if(username == ''){
            $('#e1').html('Please Provide Username');
            $('#e1').css('display','block');
            setTimeout(function() { 
              $('#e1').css('display','none');    
            },4000);
        }else if(useremail == ''){
            $('#e2').html('Please Provide UserEmail');
            $('#e2').css('display','block');
            setTimeout(function() { 
              $('#e2').css('display','none');    
            },4000);
        }else if((atpos<1 || dotpos<atpos+2 || dotpos+2>=useremail.length)){
            $('#e2').html('Please Provide Valid Email');
            $('#e2').css('display','block');
            setTimeout(function() { 
              $('#e2').css('display','none');    
            },4000);
        }else if(password == ''){
            $('#e3').html('Please Provide Password');
            $('#e3').css('display','block');
            setTimeout(function() { 
              $('#e3').css('display','none');    
            },4000);
            
        }else if(password != repassword){
            $('#e4').html('Retyupe password doesn\'t match with password');
            $('#e4').css('display','block');
            setTimeout(function() { 
              $('#e4').css('display','none');    
            },4000);
        }else{
            
              var url = "signup.php?username="+username+"&useremail="+useremail+"&password="+password+"&country="+country;
              console.log(url);
              var xhttp = new XMLHttpRequest();
              xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    var res = this.responseText.trim();
                    console.log(res);
                    if(res == '1'){
                        $('.CommonMeg').html('Registered successfully');
                        $('.CommonMeg').css('color','green');
                        $('.CommonMeg').css('display','block');
                        setTimeout(function() { 
                          $('.CommonMeg').css('display','none');    
                        },4000);
                    }else if(res == '2'){
                        $('.CommonMeg').html('User Already Registered');
                        $('.CommonMeg').css('color','red');
                        $('.CommonMeg').css('display','block');
                        setTimeout(function() { 
                          $('.CommonMeg').css('display','none');    
                        },4000);
                    }
                    
                }
              };
              xhttp.open("GET",url, true);
              xhttp.send();
            
        }
        
    }
    
    
    
    function validLog(){
        var loginemail = $('#loginemail').val();
        var loginpassword = $('#loginpassword').val();
        var atpos=loginemail.indexOf('@');
        var dotpos=loginemail.lastIndexOf('.');
        
        if(loginemail == ''){
            $('#Elog2').html('Please Provide UserEmail');
            $('#Elog2').css('display','block');
            setTimeout(function() { 
              $('#Elog2').css('display','none');    
            },4000);
        }else if((atpos<1 || dotpos<atpos+2 || dotpos+2>=loginemail.length)){
            $('#Elog2').html('Please Provide Valid Email');
            $('#Elog2').css('display','block');
            setTimeout(function() { 
              $('#Elog2').css('display','none');    
            },4000);
        }else if(loginpassword == ''){
            $('#Elog3').html('Please Provide Password');
            $('#Elog3').css('display','block');
            setTimeout(function() { 
              $('#Elog3').css('display','none');    
            },4000);
            
        }else{
            
              var url = "login.php?loginemail="+loginemail+"&loginpassword="+loginpassword;
              console.log(url);
              var xhttp = new XMLHttpRequest();
              xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    var res = this.responseText.trim();
                    console.log(res);
                    if(res == '1'){
                        $('.CommonMeg').html('Logged in successfully');
                        $('.CommonMeg').css('color','green');
                        $('.CommonMeg').css('display','block');
                        setTimeout(function() { 
                          $('.CommonMeg').css('display','none');
                          window.location='user_dashboard.php';    
                        },4000);
                    }else if(res == '-1'){
                        $('.CommonMeg').html('Check Registered Email Address');
                        $('.CommonMeg').css('color','red');
                        $('.CommonMeg').css('display','block');
                        setTimeout(function() { 
                          $('.CommonMeg').css('display','none');    
                        },4000);
                    }
                    else if(res == '-2'){
                        $('.CommonMeg').html('User doen\'t exist');
                        $('.CommonMeg').css('color','red');
                        $('.CommonMeg').css('display','block');
                        setTimeout(function() { 
                          $('.CommonMeg').css('display','none');    
                        },4000);
                    }
                    
                }
              };
              xhttp.open("GET",url, true);
              xhttp.send();
            
        }
        
    }
    
    
function chkForgot(){
        var forgotemail = $('#forgotemail').val();
        var atpos=forgotemail.indexOf('@');
        var dotpos=forgotemail.lastIndexOf('.');
        
        if(forgotemail == ''){
            $('#For1').html('Please Provide UserEmail');
            $('#For1').css('display','block');
            setTimeout(function() { 
              $('#For1').css('display','none');    
            },4000);
        }else if((atpos<1 || dotpos<atpos+2 || dotpos+2>=forgotemail.length)){
            $('#For1').html('Please Provide Valid Email');
            $('#For1').css('display','block');
            setTimeout(function() { 
              $('#For1').css('display','none');    
            },4000);
        }else{
            
            var url = "forgotpass.php?forgotemail="+forgotemail;
              console.log(url);
              var xhttp = new XMLHttpRequest();
              xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    var res = this.responseText.trim();
                    console.log(res);
                    if(res == '1'){
                        $('.CommonMeg').html('Check Your Email');
                        $('.CommonMeg').css('color','green');
                        $('.CommonMeg').css('display','block');
                        setTimeout(function() { 
                          $('.CommonMeg').css('display','none');    
                        },4000);
                    }else if(res == '-1'){
                        $('.CommonMeg').html('Check Registered Email Address');
                        $('.CommonMeg').css('color','red');
                        $('.CommonMeg').css('display','block');
                        setTimeout(function() { 
                          $('.CommonMeg').css('display','none');    
                        },4000);
                    }
                }
              };
              xhttp.open("GET",url, true);
              xhttp.send();
            
        }
        
    }
    


    function locationChange(val){
         //alert(val);
        window.location=val;
    }